"""Feature extraction utilities for phishing URL detection."""

from __future__ import annotations

import math
import re
from collections import Counter
from dataclasses import dataclass
from typing import Iterable

import numpy as np
import pandas as pd
import tldextract
from scipy.stats import entropy

SUSPICIOUS_KEYWORDS = (
    "login", "signin", "verify", "verification", "account", "secure",
    "update", "password", "bank", "confirm", "webscr", "paypal",
    "ebayisapi", "bonus", "free", "lucky", "credential", "admin",
)

IP_PATTERN = re.compile(
    r"(?<!\d)(?:25[0-5]|2[0-4]\d|1?\d?\d)"
    r"(?:\.(?:25[0-5]|2[0-4]\d|1?\d?\d)){3}(?!\d)"
)


def shannon_entropy(text: str) -> float:
    """Return Shannon entropy of a string."""
    if not text:
        return 0.0
    counts = np.array(list(Counter(text).values()), dtype=float)
    return float(entropy(counts, base=2))


def domain_name(url: str) -> str:
    """Extract the registered domain label from a URL."""
    extracted = tldextract.extract(url)
    return extracted.domain or ""


def tld_suffix(url: str) -> str:
    """Extract the public suffix/TLD from a URL."""
    return tldextract.extract(url).suffix or ""


def has_ip_address(url: str) -> bool:
    return bool(IP_PATTERN.search(url))


def has_suspicious_keyword(url: str) -> bool:
    lowered = url.lower()
    return any(keyword in lowered for keyword in SUSPICIOUS_KEYWORDS)


def has_repetition(url: str) -> bool:
    """Detect repeated characters or repeated tokens."""
    repeated_chars = bool(re.search(r"(.)\1{2,}", url))
    tokens = [token for token in re.split(r"[^a-zA-Z0-9]+", url.lower()) if token]
    repeated_tokens = len(tokens) != len(set(tokens))
    return repeated_chars or repeated_tokens


def has_redirection(url: str) -> bool:
    """Detect extra '//' after the protocol section."""
    normalized = re.sub(r"^[a-zA-Z][a-zA-Z0-9+.-]*://", "", url)
    return "//" in normalized


def learn_dangerous_characters(
    urls: pd.Series,
    labels: pd.Series,
    bad_label: str = "bad",
    top_n: int = 10,
) -> list[str]:
    """Learn special characters strongly associated with bad URLs."""
    frame = pd.DataFrame({"URL": urls.astype(str), "Label": labels})
    special_chars: set[str] = set()
    for url in frame.loc[frame["Label"] == bad_label, "URL"]:
        special_chars.update(re.findall(r"[^a-zA-Z0-9]", url))

    rows = []
    bad_urls = frame.loc[frame["Label"] == bad_label, "URL"]
    for char in special_chars:
        bad_count = int(bad_urls.str.contains(re.escape(char), regex=True).sum())
        all_count = int(frame["URL"].str.contains(re.escape(char), regex=True).sum())
        if bad_count <= 0 or all_count <= 0:
            continue
        bad_probability = bad_count / all_count
        score = bad_probability * math.log(max(bad_count, 1))
        rows.append((char, score))

    rows.sort(key=lambda item: item[1], reverse=True)
    return [char for char, _ in rows[:top_n]]


def learn_dangerous_tlds(
    urls: pd.Series,
    labels: pd.Series,
    bad_label: str = "bad",
    top_n: int = 10,
) -> list[str]:
    """Learn TLDs strongly associated with bad URLs."""
    frame = pd.DataFrame({"URL": urls.astype(str), "Label": labels})
    frame["TLD"] = frame["URL"].map(tld_suffix)
    frame = frame[frame["TLD"] != ""]

    rows = []
    for suffix in frame.loc[frame["Label"] == bad_label, "TLD"].unique():
        bad_count = int(((frame["Label"] == bad_label) & (frame["TLD"] == suffix)).sum())
        all_count = int((frame["TLD"] == suffix).sum())
        if bad_count <= 0 or all_count <= 0:
            continue
        bad_probability = bad_count / all_count
        score = bad_probability * math.log(max(bad_count, 1))
        rows.append((suffix, score))

    rows.sort(key=lambda item: item[1], reverse=True)
    return [suffix for suffix, _ in rows[:top_n]]


@dataclass
class URLFeatureExtractor:
    """Reusable extractor containing learned dangerous characters and TLDs."""

    dangerous_chars: Iterable[str]
    dangerous_tlds: Iterable[str]

    def transform_one(self, url: str) -> dict[str, float | int]:
        url = str(url).strip()
        extracted_domain = domain_name(url)
        extracted_tld = tld_suffix(url)

        return {
            "URL length": len(url),
            "Number of dots": url.count("."),
            "Number of slashes": url.count("/"),
            "Domain name length": len(extracted_domain),
            "Entropy": shannon_entropy(url),
            "IP Address": int(has_ip_address(url)),
            "Suspicious keywords": int(has_suspicious_keyword(url)),
            "Repetitions": int(has_repetition(url)),
            "Redirections": int(has_redirection(url)),
            "Dangerous characters": int(any(char in url for char in self.dangerous_chars)),
            "Dangerous TLD": int(extracted_tld in set(self.dangerous_tlds)),
        }

    def transform(self, urls: pd.Series | list[str]) -> pd.DataFrame:
        return pd.DataFrame([self.transform_one(url) for url in urls])
