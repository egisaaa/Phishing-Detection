"""Predict whether a URL is good or phishing using a saved model bundle."""

from __future__ import annotations

import argparse

import joblib


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Predict phishing URL")
    parser.add_argument("url", help="URL to classify")
    parser.add_argument("--model", default="models/best_xgb_model.joblib")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    bundle = joblib.load(args.model)
    extractor = bundle["feature_extractor"]
    model = bundle["model_pipeline"]

    features = extractor.transform([args.url])
    prediction = int(model.predict(features)[0])
    probability = float(model.predict_proba(features)[0][prediction])
    label = "GOOD (AMAN)" if prediction == 1 else "BAD (PHISHING)"

    print(f"URL       : {args.url}")
    print(f"Hasil     : {label}")
    print(f"Confidence: {probability:.2%}")


if __name__ == "__main__":
    main()
