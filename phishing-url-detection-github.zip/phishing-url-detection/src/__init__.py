"""Phishing URL detection package."""
