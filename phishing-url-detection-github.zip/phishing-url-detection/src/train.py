"""Train and evaluate phishing URL classifiers.

Run:
    python -m src.train --data data/phishing_site_urls.csv
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import joblib
import matplotlib.pyplot as plt
import numpy as np
import optuna
import pandas as pd
import seaborn as sns
from sklearn.compose import ColumnTransformer
from sklearn.decomposition import PCA
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn.model_selection import KFold, cross_val_score, train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from xgboost import XGBClassifier

from src.features import (
    URLFeatureExtractor,
    learn_dangerous_characters,
    learn_dangerous_tlds,
)

RANDOM_STATE = 22
NUMERIC_SCALE_COLUMNS = [
    "URL length",
    "Number of dots",
    "Number of slashes",
    "Domain name length",
]
PCA_COLUMNS = ["Entropy", "URL length"]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Train phishing URL classifiers")
    parser.add_argument("--data", required=True, help="Path to phishing_site_urls.csv")
    parser.add_argument("--trials", type=int, default=30, help="Optuna trials")
    parser.add_argument("--test-size", type=float, default=0.20)
    parser.add_argument("--models-dir", default="models")
    parser.add_argument("--outputs-dir", default="outputs")
    return parser.parse_args()


def validate_dataset(df: pd.DataFrame) -> pd.DataFrame:
    required = {"URL", "Label"}
    missing = required.difference(df.columns)
    if missing:
        raise ValueError(f"Missing required columns: {sorted(missing)}")

    clean = df[["URL", "Label"]].dropna().copy()
    clean["URL"] = clean["URL"].astype(str).str.strip()
    clean["Label"] = clean["Label"].astype(str).str.lower().str.strip()
    clean = clean[clean["Label"].isin(["good", "bad"])]
    if clean.empty:
        raise ValueError("Dataset has no valid 'good'/'bad' rows.")
    return clean


def build_preprocessor(feature_columns: list[str]) -> ColumnTransformer:
    passthrough_columns = [
        col for col in feature_columns
        if col not in set(NUMERIC_SCALE_COLUMNS + ["Entropy"])
    ]

    return ColumnTransformer(
        transformers=[
            ("scaled", StandardScaler(), NUMERIC_SCALE_COLUMNS),
            (
                "entropy_length_pca",
                Pipeline([("scale", StandardScaler()), ("pca", PCA(n_components=1))]),
                PCA_COLUMNS,
            ),
            ("binary", "passthrough", passthrough_columns),
        ],
        remainder="drop",
    )


def save_label_distribution(df: pd.DataFrame, output_path: Path) -> None:
    counts = df["Label"].value_counts().sort_index()
    ax = counts.plot(kind="barh", figsize=(9, 5))
    ax.spines[["top", "right"]].set_visible(False)
    ax.set_xlabel("Count")
    ax.set_ylabel("Label")
    ax.set_title("Distribution of Labels")
    plt.tight_layout()
    plt.savefig(output_path, dpi=200)
    plt.close()


def save_confusion(y_true: pd.Series, y_pred: np.ndarray, output_path: Path) -> None:
    cm = confusion_matrix(y_true, y_pred)
    plt.figure(figsize=(6, 5))
    sns.heatmap(cm, annot=True, fmt="d", cbar=False, xticklabels=["Bad", "Good"], yticklabels=["Bad", "Good"])
    plt.xlabel("Predicted")
    plt.ylabel("Actual")
    plt.title("Confusion Matrix")
    plt.tight_layout()
    plt.savefig(output_path, dpi=200)
    plt.close()


def main() -> None:
    args = parse_args()
    models_dir = Path(args.models_dir)
    outputs_dir = Path(args.outputs_dir)
    models_dir.mkdir(parents=True, exist_ok=True)
    outputs_dir.mkdir(parents=True, exist_ok=True)

    raw = validate_dataset(pd.read_csv(args.data))
    save_label_distribution(raw, outputs_dir / "label_distribution.png")

    # Split raw URLs first so learned phishing indicators do not leak test information.
    urls_train, urls_test, labels_train, labels_test = train_test_split(
        raw["URL"],
        raw["Label"],
        test_size=args.test_size,
        random_state=RANDOM_STATE,
        stratify=raw["Label"],
    )

    dangerous_chars = learn_dangerous_characters(urls_train, labels_train)
    dangerous_tlds = learn_dangerous_tlds(urls_train, labels_train)
    extractor = URLFeatureExtractor(dangerous_chars, dangerous_tlds)

    X_train_full = extractor.transform(urls_train.reset_index(drop=True))
    X_test = extractor.transform(urls_test.reset_index(drop=True))
    y_train_full = (labels_train.reset_index(drop=True) == "good").astype(int)
    y_test = (labels_test.reset_index(drop=True) == "good").astype(int)

    # Balance training data only by undersampling the majority class.
    train_frame = X_train_full.copy()
    train_frame["Label"] = y_train_full
    class_counts = train_frame["Label"].value_counts()
    target_size = int(class_counts.min())
    balanced = pd.concat(
        [
            group.sample(n=target_size, random_state=RANDOM_STATE)
            for _, group in train_frame.groupby("Label")
        ],
        ignore_index=True,
    ).sample(frac=1, random_state=RANDOM_STATE).reset_index(drop=True)

    X_train = balanced.drop(columns="Label")
    y_train = balanced["Label"]
    preprocessor = build_preprocessor(list(X_train.columns))
    kf = KFold(n_splits=10, shuffle=True, random_state=RANDOM_STATE)

    rf_pipeline = Pipeline(
        [("preprocess", preprocessor), ("model", RandomForestClassifier(random_state=RANDOM_STATE, n_jobs=-1))]
    )
    xgb_pipeline = Pipeline(
        [
            ("preprocess", preprocessor),
            ("model", XGBClassifier(random_state=RANDOM_STATE, eval_metric="logloss", n_jobs=-1)),
        ]
    )

    rf_cv = cross_val_score(rf_pipeline, X_train, y_train, cv=kf, scoring="accuracy", n_jobs=-1).mean()
    xgb_cv = cross_val_score(xgb_pipeline, X_train, y_train, cv=kf, scoring="accuracy", n_jobs=-1).mean()

    rf_pipeline.fit(X_train, y_train)
    xgb_pipeline.fit(X_train, y_train)
    rf_pred = rf_pipeline.predict(X_test)
    xgb_pred = xgb_pipeline.predict(X_test)

    def objective(trial: optuna.Trial) -> float:
        model = XGBClassifier(
            random_state=RANDOM_STATE,
            eval_metric="logloss",
            n_jobs=-1,
            n_estimators=trial.suggest_int("n_estimators", 100, 400),
            max_depth=trial.suggest_int("max_depth", 3, 7),
            learning_rate=trial.suggest_float("learning_rate", 1e-3, 0.3, log=True),
            subsample=trial.suggest_float("subsample", 0.6, 1.0),
            reg_alpha=trial.suggest_float("reg_alpha", 1e-3, 10.0, log=True),
        )
        pipeline = Pipeline([("preprocess", preprocessor), ("model", model)])
        return float(cross_val_score(pipeline, X_train, y_train, cv=kf, scoring="accuracy", n_jobs=-1).mean())

    study = optuna.create_study(direction="maximize")
    study.optimize(objective, n_trials=args.trials)

    best_pipeline = Pipeline(
        [
            ("preprocess", preprocessor),
            (
                "model",
                XGBClassifier(
                    random_state=RANDOM_STATE,
                    eval_metric="logloss",
                    n_jobs=-1,
                    **study.best_params,
                ),
            ),
        ]
    )
    best_pipeline.fit(X_train, y_train)
    best_pred = best_pipeline.predict(X_test)

    metrics = {
        "rf_cv_accuracy": float(rf_cv),
        "xgb_cv_accuracy": float(xgb_cv),
        "rf_test_accuracy": float(accuracy_score(y_test, rf_pred)),
        "xgb_test_accuracy": float(accuracy_score(y_test, xgb_pred)),
        "best_xgb_cv_accuracy": float(study.best_value),
        "best_xgb_test_accuracy": float(accuracy_score(y_test, best_pred)),
        "best_params": study.best_params,
        "dangerous_chars": dangerous_chars,
        "dangerous_tlds": dangerous_tlds,
    }

    save_confusion(y_test, best_pred, outputs_dir / "confusion_matrix_best_xgb.png")
    (outputs_dir / "metrics.json").write_text(json.dumps(metrics, indent=2), encoding="utf-8")
    (outputs_dir / "classification_report.txt").write_text(
        classification_report(y_test, best_pred, target_names=["Bad", "Good"]),
        encoding="utf-8",
    )

    bundle = {"feature_extractor": extractor, "model_pipeline": best_pipeline}
    joblib.dump(bundle, models_dir / "best_xgb_model.joblib")

    print(json.dumps(metrics, indent=2))
    print(f"Saved model: {models_dir / 'best_xgb_model.joblib'}")


if __name__ == "__main__":
    main()
